close all
clear all
clc

%%gui
cell_list = {};

fig_number = 1;
title_figure ='SWARD  (super-wide-angle-lens radial distortion correction) camera calibration toolbox';

cell_list{1,1} = {'Read image','Img_read1;'};
cell_list{1,2} = {'Select points','Get_points2;'};
cell_list{1,3} = {'Comp. DoC','Get_DoC;'};
cell_list{1,4} = {'Distortion Calibration','Distortion_com;'};

cell_list{2,1} = {'Undistort image','Distortion_Correct;'};
cell_list{2,2} = {'Save Image','Img_save;'};
cell_list{2,3} ={'Quit',['disp(''To run again, type main_gui.''); close(' num2str(fig_number) ');']};

show_window(cell_list,fig_number,title_figure,130,18,0,'clean',12);

