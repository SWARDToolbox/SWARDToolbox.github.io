% Copyright (c) 2012, Xianghua Ying
% All rights reserved.
% SWARD Camera Calibration Toolbox
% Vision:1.0
% Author:  Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Jiangpeng Rong, Hongbin Zha, 2014/10/08
% Notes: 
%- This toolbox is designed for radial lens distortion correction from a single image of a planar pattern.   
%- If you used this code please refer(use) this references:
%- Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Hongbin Zha, Radial distortion correction from a single image of a planar calibration pattern using convex optimization, IEEE International Conference on Image Processing (ICIP), 2014
%- Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Jiangpeng Rong, Hongbin Zha, Imposing Differential Constraints on Radial Distortion Correction, the 12th Asian Conference on Computer Vision (ACCV'14), 2014.
%- Please for any help send to us: xhying@cis.pku.edu.cn

close all
clear all
clc

%%gui
cell_list = {};

fig_number = 1;
title_figure ='SWARD  (super-wide-angle-lens radial distortion correction) camera calibration toolbox';

cell_list{1,1} = {'Read Image','Img_read1;'};
cell_list{1,2} = {'Distortion Calibration','Distortion_cal;'};
cell_list{1,3} = {'Save','Img_save;'};
cell_list{1,4} ={'Quit',['disp(''To run again, type main_gui.''); close(' num2str(fig_number) ');']};

show_window(cell_list,fig_number,title_figure,120,18,0,'clean',12);

