

display('***********************************INPUT***********************************************')
%directory
dir='data/' ;

image1 =  input('Please input the name of distorted image: ([]=''c01.bmp'') ','s');
if isempty(image1),
   		image1 = 'c01.bmp';
%         image1 = '3111.bmp';
end;

image1 = [dir  image1];
img_dis = imread(image1);

if (not(isempty(img_dis)))
    display('Input success!');
end
    
 display('**********************************************************************************')
 
image2 =  input('Please input the name of original chessboard image: ([]=''c_chessboard.jpg'') ','s');

if isempty(image2),
   		image2 = 'c_chessboard.jpg';
end;

image2 = [dir  image2];
img_chess = imread(image2);

if (not(isempty(img_chess)))
    display('Input success!');
end

clear image1 image2

display('*************************************END*********************************************')
    

 
    
  
    