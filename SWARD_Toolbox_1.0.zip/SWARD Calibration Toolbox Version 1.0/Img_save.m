
imwrite(IR,'img_correct.bmp');