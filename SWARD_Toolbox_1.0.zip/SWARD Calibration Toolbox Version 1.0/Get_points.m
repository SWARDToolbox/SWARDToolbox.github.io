
POINTS =20;%ѡȡ��Ӧ�����
color_temp=[1 0 0];%��Ӧ�����ɫ

%%randomly select
while(1)
    xxr=round(rand(1,POINTS)*(11-1));%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    yyr=round(rand(1,POINTS)*(15-1));
    xyt=yyr*12+xxr+1;
    xyt1= unique(xyt);
    if length(xyt1)==POINTS
        break;
    end
    end

[sss rr]=sort(xyt);
xnum=xxr(rr);
ynum=yyr(rr);

x1=xnum*50+10;
y1=ynum*50+10;

figure
imshow(img_chess)
hold on
for i=1:POINTS
    
    plot(y1(i),x1(i),'*','color',color_temp);
    text(y1(i),x1(i),num2str(i),'FontSize',17,'color',color_temp);
    
end



figure(2);
image(img_dis);
%colormap(map);
set(2,'color',[1 1 1]);

% title(['Click on the four extreme corners of the rectangular pattern (first corner = origin)... Image ' num2str(kk)]);

% disp('Click on the four extreme corners of the rectangular complete pattern (the first clicked corner is the origin)...');
winty=5;
wintx=5;
x= [];y = [];
figure(2); hold on;
for count = 1:4,
    [xi,yi] = ginput4(1);
    [xxi] = cornerfinder([xi;yi],img_dis);
    xi = xxi(1);
    yi = xxi(2);
    figure(2);
    plot(xi,yi,'+','color',[ 1.000 0.314 0.510 ],'linewidth',2);
     plot(xi + [wintx+.5 -(wintx+.5) -(wintx+.5) wintx+.5 wintx+.5],yi + [winty+.5 winty+.5 -(winty+.5) -(winty+.5)  winty+.5],'-','color',[ 1.000 0.314 0.510 ],'linewidth',2);
    x = [x;xi];
    y = [y;yi];
%     plot(x,y,'-','color',[ 1.000 0.314 0.510 ],'linewidth',2);
    drawnow;%drawnow����ˢ����Ļ��
end;
% plot([x;x(1)],[y;y(1)],'-','color',[ 1.000 0.314 0.510 ],'linewidth',2);
drawnow;
hold off;





break
%distorted image
figure
imshow(img_dis);
hold on

pause(1);%��ͣ
pixel_x=[];
pixel_y=[];
for i=1:POINTS
    
    [temp_x,temp_y] = ginput(1);
    
    plot(temp_x,temp_y,'*','color',color_temp);
    text(temp_x,temp_y,num2str(i),'FontSize',17,'color',color_temp);
    
    pixel_x(i) = temp_x;
    pixel_y(i) = temp_y;
end
hold off
x1d=pixel_y;
y1d=pixel_x;





%%
% %chessboard
%manually select points
% figure
% imshow(img_chess)
% hold on
% pixel_x=[];
% pixel_y=[];
% for i=1:POINTS
%     [temp_x,temp_y] = ginput(1);
%     
%     plot(temp_x,temp_y,'*','color',color_temp);
%     text(temp_x,temp_y,num2str(i),'FontSize',17,'color',color_temp);
%     
%     pixel_x(i) = temp_x;
%     pixel_y(i) = temp_y;
% end
% 
% x1= pixel_y;
% y1= pixel_x;




