
disp('===============Corner detection automatically=================');

addpath('matching');

% I1= imread('data/chessboard.jpg');
% I2= imread('data/dis_1.bmp');
I1= img_chess;
I2= img_dis;

%%chessboard
tic
corners1 = findCorners(I1,0.01,1);
chessboards1 = chessboardsFromCorners(corners1);
cb1 = chessboards1{1};
p1 = corners1.p(cb1,:)+1;
toc

%%distortion
tic
corners2 = findCorners(I2,0.01,1);
chessboards2 = chessboardsFromCorners(corners2);
cb2 = chessboards2{1};
p2 = corners2.p(cb2,:)+1;
toc

[tt1 a]=size(cb1);
[tt2 a]=size(cb2);

if tt1~=tt2    
    [Lm Ln]=size(cb2);
    rr=reshape([1:Lm*Ln],Ln,Lm)';
    rr=fliplr(rr);
    rr=rr(:);
    p1=p1(rr,:);    
end

% xnum=round(rand(1,NoGrid)*(Lm-1))+1;%%%%%%%%%%%%%%
% ynum=round(rand(1,NoGrid)*(Ln-1))+1;%%%%%%%%%%%%%%
%
% tt=(ynum-1)*Lm+xnum;
% tt=sort(tt);
% xy1=cb1(tt);
% xy2=cb2(tt);

POINTS =20;%ѡȡ��Ӧ�����

[Len a]=size(p1);
while(1)
    xynum=round(rand(1,POINTS)*( Len-1))+1;
    xynum= unique(xynum);
    if length(xynum)==POINTS
        break;
    end
end
xynum=sort(xynum);

%%�õ���Ӧ��
%chessboard
x1=p1(xynum,2)';
y1=p1(xynum,1)';
%Distrotion
x1d=p2(xynum,2)';
y1d=p2(xynum,1)';

color_temp=[1 0 0];%��Ӧ�����ɫ
figure; imshow(uint8(I1)); hold on;
for ii=1:POINTS
    %      tt=xynum(ii);
    plot(y1(ii),x1(ii),'r*');
    text(y1(ii),x1(ii),num2str(ii),'FontSize',15,'color',color_temp);
    
end

figure; imshow(uint8(I2)); hold on;
for ii=1:POINTS
    tt=xynum(ii);
    plot(y1d(ii),x1d(ii),'r*');
    text(y1d(ii),x1d(ii),num2str(ii),'FontSize',15,'color',color_temp);
end




