%%correct the distorted image

It2 = img_dis; %RGB
% It2 = rgb2gray(img_dis);%gray

%size of the distortion image
[ms ns t]=size(It2);

%new iamge size
ttt=1+rlamda*((ms/2)^2+(ns/2)^2) %%The largest magnification
if(ttt>1)
    mc=ms;
    nc=ns;
elseif(ttt<0.3)
    mc=ms*4;
    nc=ns*4;
else
    mc=round(ms/ttt);
    nc=round(ns/ttt);
end

IR=ones(mc, nc,3);
% cx=mc/2;
% cy=nc/2;
cx=mc*centerX/ms;
cy=nc*centerY/ns;

% the distortion parameter of the  division model
k=rlamda;

[m,n]=size(IR);
for ii=1:m
    for jj=1:n
        
        tx=ii-cx;
        ty=jj-cy;
        tR=(tx)^2+(ty)^2;
        s=(1-sqrt(1-4*k*tR))/(2*k*tR);%the distortion parameter for every point
        
        x=round(tx*s+centerX);
        y=round(ty*s+centerY);
        
        if(x>0 & y>0&x<ms+1&y<ns+1)
            IR(ii,jj,:)=It2(x,y,:);%RGB
            %IR(ii,jj)=It2(x,y);    %Gray
        end
    end
end

% IR=round(IR);
IR=uint8(IR);

%the corrected image
figure
imshow(IR)

