
disp('===============Corner detection automatically=================');
Get_points;

disp('===============Calculate the distortion center=================');
Get_DoC;

disp('===============Distortion calibration=================');
Distortion_com;

disp('===============Correct the distrtion image=================');
Distortion_Correct;