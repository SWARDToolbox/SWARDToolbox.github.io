function DoC=computeDoC(x1,y1,x1d,y1d)
   
    xs=[x1;y1;ones(1,length(x1))];
    xsd=[x1d;y1d;ones(1,length(x1d))];
    F=det_F_normalized_8point(xs,xsd);
    [e,eprime]= get_epipole(F);
    DoC=eprime/eprime(3);