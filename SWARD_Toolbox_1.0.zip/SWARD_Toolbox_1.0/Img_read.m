disp('===============Input an image=================');

%select an image
[filename,pathname,fileindex]=uigetfile(...
    {'*.bmp';'*.jpg';'*.png'},...
    'Please select an image for distortion calibration ');

image1 = [pathname  filename];
img_dis = imread(image1);

if (not(isempty(img_dis)))
    display('success!');
else
       display('Error!   Please reselect an image!');
end

% display('*************************************END*********************************************')  
  
    