% Copyright (c) 2014, Xianghua Ying
% All rights reserved.
% SWARD Camera Calibration Toolbox
% Vision:1.0
% Author:  Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Jiangpeng Rong, Hongbin Zha, 2014/10/08
% Notes: 
%- This toolbox is designed for radial lens distortion correction from a single image of a planar pattern.   
%- If you used this code please refer(use) this references:
%- Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Hongbin Zha, Radial distortion correction from a single image of a planar calibration pattern using convex optimization, IEEE International Conference on Image Processing (ICIP), 2014
%- Xianghua Ying, Xiang Mei, Sen Yang, Ganwen Wang, Jiangpeng Rong, Hongbin Zha, Imposing Differential Constraints on Radial Distortion Correction, the 12th Asian Conference on Computer Vision (ACCV'14), 2014.
%- This toolbox also used the Matlab code of LIBCBDETECT in the 'matching' folder to detect  sub-pixel chessboard pattern automatically.
%- And you can find the LIBCBDETECT code from the second reference of our  website.
%- Please for any help send to us: xhying@cis.pku.edu.cn

disp('===============Input an image=================');

%select an image
[filename,pathname,fileindex]=uigetfile(...
    {'*.jpg';},...
    'Please select an image for distortion calibration ');

image1 = [pathname  filename];
img_dis = imread(image1);

if (not(isempty(img_dis)))
    display('success!');
else
       display('Error!   Please reselect an image!');
end

% display('*************************************END*********************************************')  
  
    