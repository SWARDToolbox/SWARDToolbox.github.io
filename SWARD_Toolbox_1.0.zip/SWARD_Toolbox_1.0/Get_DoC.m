%%compute the distortion of center
xs=[x1;y1;ones(1,length(x1))];
xsd=[x1d;y1d;ones(1,length(x1d))];

F=det_F_normalized_8point(xs,xsd);
[e,eprime]= get_epipole(F);
DoC=eprime/eprime(3);

display('The distortion of center is:')
round([DoC(1) DoC(2)])

figure
imshow(img_dis)
hold on
plot(DoC(2),DoC(1),'r*');
% xx=round([DoC(2) DoC(1)])
text(DoC(2),DoC(1),' Center of Distortion','FontSize',15,'color',[1 0 0]);  
hold off

%%error
[m n t]=size(img_dis);
% DoC(1:2)-[m/2 n/2]'
clear xs xsd
