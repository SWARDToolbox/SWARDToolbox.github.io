
close all;clear all;clc
%%gui
warning('off');

cell_list = {};

fig_number = 1;
title_figure ='SWARD  (super-wide-angle-lens radial distortion correction) camera calibration toolbox';

cell_list{1,1} = {'Read Image','Img_read;'};
cell_list{1,2} = {'Distortion Calibration','Distortion_cal;'};
cell_list{1,3} = {'Save','Img_save;'};
cell_list{1,4} ={'Quit',['disp(''To run again, type main_gui.''); close(' num2str(fig_number) ');']};

show_window(cell_list,fig_number,title_figure,120,18,0,'clean',12);

