%%save the corrected image

Sp=regexp(filename,'\.', 'split');
filenamet=Sp{1};
img_suffix=Sp{2};

nameofcor=[filenamet  '_correct' '.' img_suffix];

imwrite(IR,nameofcor);